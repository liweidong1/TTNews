# TTNews

如果下载太慢了，可以来这个网站上下载http://www.codedata.cn/cdetail/Objective-C/Demo/1471438806256270


![image](https://github.com/577528249/TTNews/blob/master/introductionimages/1234.gif)


作为一个集新闻与娱乐于一体的新闻客户端，


她具有阅读新闻，观赏搞笑图片，观赏搞笑视频等功能，	


她采用MVC架构，拥有新闻，图片，视频，我四个模块，


她所涉及的技术有网络请求，视频播放，数据持久化，陀螺仪监测等，


如果您认为她对您有所帮助，希望您能为她点一下star，感谢您的访问！


PS:她的新闻数据源来自于百度API Store里的免费新闻api，

轮播图数据接口http://apistore.baidu.com/apiworks/servicedetail/1570.html


新闻接口http://apistore.baidu.com/apiworks/servicedetail/688.html



她的搞笑图片，搞笑视频数据源来自于百思不得姐
（api由抓包分析网络请求所得，版权归百思不得姐所有），


新手项目，多多包涵，谢谢！有相关问题可以在线留言或发邮件至577528249@qq.com，谢谢！


#使用方法


点击右上角Download Zip按钮，将项目压缩包下载至本地，解压后点击文件夹中TTNews.xcworkspace即可运行。





# 新闻首页


![image](https://github.com/577528249/TTNews/blob/master/introductionimages/IMG_0345.PNG)
















# 图片界面


![image](https://github.com/577528249/TTNews/blob/master/introductionimages/IMG_0346.PNG)















# 视频界面


![image](https://github.com/577528249/TTNews/blob/master/introductionimages/IMG_0347.PNG)











# 我的界面

![image](https://github.com/577528249/TTNews/blob/master/introductionimages/IMG_0349.PNG)




#License
The MIT License (MIT)

Copyright (c) 2016 YangJunhui

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
