//
//  UserInfoCell.h
//  TTNews
//
//  Created by 瑞文戴尔 on 16/8/10.
//  Copyright © 2016年 瑞文戴尔. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UserInfoCell : UITableViewCell
-(void)setAvatarImage:(UIImage *)image Name:(NSString *)name Signature:(NSString *)content;
@end
