//
//  SwitchCell.h
//  TTNews
//
//  Created by 瑞文戴尔 on 16/8/10.
//  Copyright © 2016年 瑞文戴尔. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SwitchCell : UITableViewCell
@property (nonatomic, weak) UILabel *leftLabel;
@property (nonatomic, weak) UISwitch *theSwitch;
@end
