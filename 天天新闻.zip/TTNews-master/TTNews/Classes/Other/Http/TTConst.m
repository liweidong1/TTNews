//
//  TTConst.m
//  TTNews
//
//  Created by 瑞文戴尔 on 16/3/30.
//  Copyright © 2016年 瑞文戴尔. All rights reserved.
//
#import <UIKit/UIKit.h>

CGFloat const cellMargin = 10;
CGFloat const cellTextY = 55;
CGFloat const cellBottomBarHeight = 40;
CGFloat const cellTopCommentTopLabelHeight = 16;
NSString * const IsShakeCanChangeSkinKey = @"IsShakeCanChangeSkinKey";
NSString * const IsDownLoadNoImageIn3GKey = @"IsDownLoadNoImageIn3GKey";
NSString * const UserNameKey = @"UserNameKey";
NSString * const UserSignatureKey = @"UserSignatureKey";
