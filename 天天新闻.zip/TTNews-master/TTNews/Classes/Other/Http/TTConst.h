//
//  TTConst.h
//  TTNews
//
//  Created by 瑞文戴尔 on 16/3/30.
//  Copyright © 2016年 瑞文戴尔. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

UIKIT_EXTERN CGFloat const cellMargin;
UIKIT_EXTERN CGFloat const cellTextY;
UIKIT_EXTERN CGFloat const cellBottomBarHeight;
UIKIT_EXTERN CGFloat const cellTopCommentTopLabelHeight;

extern NSString * const IsShakeCanChangeSkinKey;
extern NSString * const IsDownLoadNoImageIn3GKey;
extern NSString * const UserNameKey;
extern NSString * const UserSignatureKey;
