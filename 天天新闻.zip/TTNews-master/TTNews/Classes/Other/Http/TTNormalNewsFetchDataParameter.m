//
//  TTNormalNewsFetchDataParameter.m
//  TTNews
//
//  Created by 瑞文戴尔 on 16/4/11.
//  Copyright © 2016年 瑞文戴尔. All rights reserved.
//

#import "TTNormalNewsFetchDataParameter.h"

@implementation TTNormalNewsFetchDataParameter

@end
