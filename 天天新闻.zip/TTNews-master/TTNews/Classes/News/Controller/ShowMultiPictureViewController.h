//
//  ShowMultiPictureViewController.h
//  TTNews
//
//  Created by 瑞文戴尔 on 16/3/31.
//  Copyright © 2016年 瑞文戴尔. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShowMultiPictureViewController : UIViewController

@property (nonatomic, strong) NSArray *imageUrls;
@property (nonatomic, strong) NSString *text;

@end
