//
//  BigPictureTableViewCell.m
//  TTNews
//
//  Created by 瑞文戴尔 on 16/9/19.
//  Copyright © 2016年 瑞文戴尔. All rights reserved.
//

#import "BigPictureTableViewCell.h"

@implementation BigPictureTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
