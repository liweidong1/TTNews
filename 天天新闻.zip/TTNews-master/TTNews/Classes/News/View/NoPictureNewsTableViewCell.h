//
//  NoPictureNewsTableViewCell.h
//  TTNews
//
//  Created by 瑞文戴尔 on 16/4/14.
//  Copyright © 2016年 瑞文戴尔. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NoPictureNewsTableViewCell : UITableViewCell

@property (nonatomic, copy) NSString *titleText;
@property (nonatomic, copy) NSString *contentText;


@end
